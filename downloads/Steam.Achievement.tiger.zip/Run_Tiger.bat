@echo off
title Steam Achievement tiger
cd /d "%~dp0"
powershell -Command "Get-ChildItem -Path '%~dp0' -Recurse | Unblock-File -ErrorAction SilentlyContinue" 2>nul
start "" "TIGER.Picker.exe"
exit
